# MMASSITI Moderno — Protótipo em Python

Protótipo moderno inspirado na aplicação legacy **MMASSI/TI — Metodologia Multicritério de Apoio à Seleção de SI/TI**.

Esta versão usa:

- Python
- Streamlit
- ficheiros JSON simples
- cálculo multicritério por soma ponderada
- análise benefício/custo
- análise de sensibilidade
- análise de robustez

## Como executar

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Estrutura

```text
app.py                    Interface Streamlit
core/models.py            Modelos de dados
core/storage.py           Leitura/escrita JSON
core/calculation.py       Motor de cálculo multicritério
core/sample_data.py       Geração de exemplo inicial
data/sample_analysis.json Exemplo de análise
exports/                  Pasta para exportações futuras
```

## Nota importante

O pacote legacy analisado continha apenas o executável VB6 e a base de dados Access, não o código-fonte original.
Por isso, esta implementação reconstrói a lógica funcional a partir dos conceitos observados:

- análises
- alternativas
- critérios
- níveis de atratividade
- pesos
- custos
- primeira e segunda fase
- benefício/custo
- sensibilidade
- robustez
- relatórios

As fórmulas podem ser ajustadas posteriormente se forem disponibilizados exemplos de input/output da aplicação original.
