from __future__ import annotations

from typing import Dict, List, Optional, Literal
from pydantic import BaseModel, Field


Phase = Literal[1, 2]


class Level(BaseModel):
    """Nível de atratividade associado a um critério."""
    name: str = "Nível"
    score: float = 0.0
    description: str = ""


class Criterion(BaseModel):
    """Critério de avaliação multicritério."""
    code: str
    name: str
    phase: Phase = 1
    selected: bool = True
    description: str = ""
    order: int = 0
    weight: float = 1.0
    is_cost: bool = False
    neutral_level: Optional[str] = None
    best_level: Optional[str] = None
    levels: List[Level] = Field(default_factory=list)


class Alternative(BaseModel):
    """Alternativa/SI/TI a avaliar."""
    name: str
    description: str = ""
    cost: float = 0.0
    selected_for_phase2: bool = False


class Analysis(BaseModel):
    """Análise completa."""
    name: str = "Nova análise"
    description: str = ""
    methodology: Literal["1fase", "2fases", "1e2fases"] = "1fase"
    alternatives: List[Alternative] = Field(default_factory=list)
    criteria: List[Criterion] = Field(default_factory=list)

    # scores[alternative_name][criterion_code] = value
    # value should typically be in [0, 100], but the engine also normalizes arbitrary scales.
    scores: Dict[str, Dict[str, float]] = Field(default_factory=dict)

    created_by: str = ""
    notes: str = ""


class ResultRow(BaseModel):
    alternative: str
    phase: Phase
    value: float
    cost: float
    benefit_cost: Optional[float] = None
    rank: int = 0


class SensitivityPoint(BaseModel):
    criterion_code: str
    factor: float
    alternative: str
    value: float
    rank: int
