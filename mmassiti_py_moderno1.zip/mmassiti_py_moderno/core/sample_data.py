from __future__ import annotations

from .models import Analysis, Alternative, Criterion, Level


def create_sample_analysis() -> Analysis:
    criteria = [
        Criterion(
            code="C1",
            name="Adequação funcional",
            phase=1,
            selected=True,
            description="Grau de cobertura das necessidades funcionais.",
            order=1,
            weight=35,
            levels=[
                Level(name="Fraco", score=20),
                Level(name="Médio", score=50),
                Level(name="Bom", score=80),
                Level(name="Excelente", score=100),
            ],
            neutral_level="Médio",
            best_level="Excelente",
        ),
        Criterion(
            code="C2",
            name="Facilidade de integração",
            phase=1,
            selected=True,
            description="Capacidade de integração com sistemas existentes.",
            order=2,
            weight=25,
            levels=[
                Level(name="Baixa", score=20),
                Level(name="Média", score=60),
                Level(name="Alta", score=100),
            ],
            neutral_level="Média",
            best_level="Alta",
        ),
        Criterion(
            code="C3",
            name="Usabilidade",
            phase=1,
            selected=True,
            description="Facilidade de uso por utilizadores finais e administradores.",
            order=3,
            weight=20,
            levels=[
                Level(name="Baixa", score=25),
                Level(name="Média", score=60),
                Level(name="Alta", score=100),
            ],
            neutral_level="Média",
            best_level="Alta",
        ),
        Criterion(
            code="C4",
            name="Risco de implementação",
            phase=1,
            selected=True,
            description="Risco técnico e organizacional. Sendo custo/risco, menor é melhor.",
            order=4,
            weight=20,
            is_cost=True,
            levels=[
                Level(name="Baixo", score=20),
                Level(name="Médio", score=60),
                Level(name="Alto", score=100),
            ],
            neutral_level="Médio",
            best_level="Baixo",
        ),
        Criterion(
            code="C5",
            name="Escalabilidade",
            phase=2,
            selected=True,
            description="Capacidade de crescimento futuro.",
            order=1,
            weight=50,
            levels=[
                Level(name="Baixa", score=20),
                Level(name="Média", score=60),
                Level(name="Alta", score=100),
            ],
        ),
        Criterion(
            code="C6",
            name="Manutenibilidade",
            phase=2,
            selected=True,
            description="Facilidade de manutenção e evolução.",
            order=2,
            weight=50,
            levels=[
                Level(name="Baixa", score=20),
                Level(name="Média", score=60),
                Level(name="Alta", score=100),
            ],
        ),
    ]

    alternatives = [
        Alternative(name="Sistema A", cost=85000, description="Solução comercial consolidada."),
        Alternative(name="Sistema B", cost=60000, description="Solução open-source com customização."),
        Alternative(name="Sistema C", cost=105000, description="Solução enterprise com suporte completo."),
    ]

    scores = {
        "Sistema A": {"C1": 85, "C2": 70, "C3": 80, "C4": 45, "C5": 75, "C6": 80},
        "Sistema B": {"C1": 70, "C2": 85, "C3": 65, "C4": 55, "C5": 70, "C6": 60},
        "Sistema C": {"C1": 95, "C2": 60, "C3": 85, "C4": 35, "C5": 95, "C6": 90},
    }

    return Analysis(
        name="Exemplo MMASSITI Moderno",
        description="Exemplo de avaliação multicritério de sistemas SI/TI.",
        methodology="1e2fases",
        alternatives=alternatives,
        criteria=criteria,
        scores=scores,
        created_by="MMASSITI Moderno",
        notes="Exemplo inicial editável.",
    )
