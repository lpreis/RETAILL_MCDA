from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional
import copy

import pandas as pd

from .models import Analysis, Criterion, ResultRow, Phase


def _selected_criteria(analysis: Analysis, phase: Phase) -> List[Criterion]:
    return [
        c for c in analysis.criteria
        if c.selected and c.phase == phase
    ]


def normalize_weights(criteria: List[Criterion]) -> Dict[str, float]:
    """Normaliza pesos para soma 1. Se todos forem zero, usa pesos iguais."""
    if not criteria:
        return {}

    total = sum(max(0.0, c.weight) for c in criteria)
    if total <= 0:
        equal = 1.0 / len(criteria)
        return {c.code: equal for c in criteria}

    return {c.code: max(0.0, c.weight) / total for c in criteria}


def criterion_scale_bounds(analysis: Analysis, criterion: Criterion) -> tuple[float, float]:
    """Obtém limites de normalização a partir de níveis ou valores observados."""
    values = []
    if criterion.levels:
        values.extend(level.score for level in criterion.levels)

    for alt in analysis.alternatives:
        values.append(float(analysis.scores.get(alt.name, {}).get(criterion.code, 0.0)))

    if not values:
        return 0.0, 100.0

    lo, hi = min(values), max(values)
    if lo == hi:
        # assume escala 0-100 se não houver variação
        return 0.0, 100.0
    return lo, hi


def normalize_score(value: float, lo: float, hi: float, is_cost: bool = False) -> float:
    """Normaliza score para [0, 100].

    Para critérios de benefício: maior é melhor.
    Para critérios de custo/penalização: menor é melhor.
    """
    if hi == lo:
        return 100.0

    normalized = (value - lo) / (hi - lo) * 100.0
    normalized = max(0.0, min(100.0, normalized))
    if is_cost:
        normalized = 100.0 - normalized
    return normalized


def evaluate_phase(analysis: Analysis, phase: Phase) -> pd.DataFrame:
    """Calcula valor global por alternativa numa fase."""
    criteria = _selected_criteria(analysis, phase)
    weights = normalize_weights(criteria)

    rows = []
    for alt in analysis.alternatives:
        total = 0.0
        detail = {}

        for criterion in criteria:
            raw = float(analysis.scores.get(alt.name, {}).get(criterion.code, 0.0))
            lo, hi = criterion_scale_bounds(analysis, criterion)
            normalized = normalize_score(raw, lo, hi, criterion.is_cost)
            contribution = normalized * weights.get(criterion.code, 0.0)
            total += contribution
            detail[f"{criterion.code} bruto"] = raw
            detail[f"{criterion.code} norm."] = normalized
            detail[f"{criterion.code} contrib."] = contribution

        benefit_cost = None
        if alt.cost and alt.cost > 0:
            benefit_cost = total / alt.cost

        rows.append({
            "Alternativa": alt.name,
            "Fase": phase,
            "Valor Global": round(total, 4),
            "Custo": alt.cost,
            "Benefício/Custo": round(benefit_cost, 6) if benefit_cost is not None else None,
            **detail,
        })

    df = pd.DataFrame(rows)
    if df.empty:
        return df

    df = df.sort_values(["Valor Global", "Benefício/Custo"], ascending=[False, False], na_position="last")
    df.insert(0, "Ranking", range(1, len(df) + 1))
    return df.reset_index(drop=True)


def evaluate_all(analysis: Analysis) -> Dict[int, pd.DataFrame]:
    """Avalia fases disponíveis."""
    result = {}
    for phase in (1, 2):
        if _selected_criteria(analysis, phase):
            result[phase] = evaluate_phase(analysis, phase)
    return result


def sensitivity_analysis(
    analysis: Analysis,
    phase: Phase,
    criterion_code: str,
    factors: List[float] | None = None,
) -> pd.DataFrame:
    """Varia o peso de um critério e recalcula rankings.

    factors representa multiplicadores do peso original: 0.5 significa -50%, 1.5 significa +50%.
    """
    if factors is None:
        factors = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]

    rows = []
    for factor in factors:
        modified = copy.deepcopy(analysis)
        for c in modified.criteria:
            if c.code == criterion_code and c.phase == phase:
                c.weight = c.weight * factor

        df = evaluate_phase(modified, phase)
        if df.empty:
            continue

        for _, row in df.iterrows():
            rows.append({
                "Critério": criterion_code,
                "Multiplicador do Peso": factor,
                "Ranking": int(row["Ranking"]),
                "Alternativa": row["Alternativa"],
                "Valor Global": float(row["Valor Global"]),
            })

    return pd.DataFrame(rows)


def robustness_analysis(
    analysis: Analysis,
    phase: Phase,
    weight_delta: float = 0.10,
) -> pd.DataFrame:
    """Análise simples de robustez.

    Para cada critério, reduz e aumenta o peso em `weight_delta` e observa se a alternativa vencedora muda.
    """
    base_df = evaluate_phase(analysis, phase)
    if base_df.empty:
        return pd.DataFrame()

    base_winner = base_df.iloc[0]["Alternativa"]
    rows = []

    criteria = _selected_criteria(analysis, phase)
    for criterion in criteria:
        for direction, factor in [("redução", 1 - weight_delta), ("aumento", 1 + weight_delta)]:
            modified = copy.deepcopy(analysis)
            for c in modified.criteria:
                if c.code == criterion.code and c.phase == phase:
                    c.weight = c.weight * factor

            df = evaluate_phase(modified, phase)
            if df.empty:
                continue

            winner = df.iloc[0]["Alternativa"]
            rows.append({
                "Critério": criterion.code,
                "Variação": direction,
                "Fator": factor,
                "Vencedor Base": base_winner,
                "Vencedor Após Variação": winner,
                "Ranking Estável?": winner == base_winner,
                "Valor Vencedor": float(df.iloc[0]["Valor Global"]),
            })

    return pd.DataFrame(rows)
