from core.storage import load_analysis
from core.calculation import evaluate_all, sensitivity_analysis, robustness_analysis

a = load_analysis("data/sample_analysis.json")
results = evaluate_all(a)
assert 1 in results
assert not results[1].empty
print(results[1][["Ranking", "Alternativa", "Valor Global", "Benefício/Custo"]])
print(sensitivity_analysis(a, 1, "C1").head())
print(robustness_analysis(a, 1))
