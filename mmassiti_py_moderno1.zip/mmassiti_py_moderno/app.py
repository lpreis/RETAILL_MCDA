from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

from core.models import Analysis, Alternative, Criterion, Level
from core.storage import (
    DATA_DIR,
    analysis_to_json,
    list_analysis_files,
    load_analysis,
    load_analysis_from_json_text,
    save_analysis,
)
from core.sample_data import create_sample_analysis
from core.calculation import (
    evaluate_all,
    evaluate_phase,
    normalize_weights,
    sensitivity_analysis,
    robustness_analysis,
)


st.set_page_config(
    page_title="MMASSITI Moderno",
    page_icon="📊",
    layout="wide",
)


def init_state() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    sample_path = DATA_DIR / "sample_analysis.json"
    if not sample_path.exists():
        save_analysis(create_sample_analysis(), sample_path)

    if "analysis" not in st.session_state:
        st.session_state.analysis = load_analysis(sample_path)
        st.session_state.current_path = str(sample_path)


def rerun_save(path: str | Path | None = None):
    saved_path = save_analysis(st.session_state.analysis, path or st.session_state.get("current_path"))
    st.session_state.current_path = str(saved_path)
    st.toast(f"Guardado em {saved_path.name}")


def criteria_dataframe(analysis: Analysis) -> pd.DataFrame:
    return pd.DataFrame([
        {
            "Código": c.code,
            "Nome": c.name,
            "Fase": c.phase,
            "Selecionado": c.selected,
            "Peso": c.weight,
            "Custo/Risco?": c.is_cost,
            "Ordem": c.order,
            "Descrição": c.description,
        }
        for c in analysis.criteria
    ])


def alternatives_dataframe(analysis: Analysis) -> pd.DataFrame:
    return pd.DataFrame([
        {
            "Nome": a.name,
            "Custo": a.cost,
            "Selecionada para 2.ª fase": a.selected_for_phase2,
            "Descrição": a.description,
        }
        for a in analysis.alternatives
    ])


def scores_dataframe(analysis: Analysis) -> pd.DataFrame:
    rows = []
    for alt in analysis.alternatives:
        row = {"Alternativa": alt.name}
        for c in analysis.criteria:
            row[c.code] = float(analysis.scores.get(alt.name, {}).get(c.code, 0.0))
        rows.append(row)
    return pd.DataFrame(rows)


def apply_alternatives_dataframe(df: pd.DataFrame) -> None:
    st.session_state.analysis.alternatives = [
        Alternative(
            name=str(row["Nome"]).strip(),
            cost=float(row.get("Custo", 0) or 0),
            selected_for_phase2=bool(row.get("Selecionada para 2.ª fase", False)),
            description=str(row.get("Descrição", "") or ""),
        )
        for _, row in df.iterrows()
        if str(row.get("Nome", "")).strip()
    ]


def apply_criteria_dataframe(df: pd.DataFrame) -> None:
    old_by_code = {c.code: c for c in st.session_state.analysis.criteria}
    new_criteria = []
    for _, row in df.iterrows():
        code = str(row.get("Código", "")).strip()
        if not code:
            continue

        old = old_by_code.get(code)
        levels = old.levels if old else []
        neutral_level = old.neutral_level if old else None
        best_level = old.best_level if old else None

        new_criteria.append(
            Criterion(
                code=code,
                name=str(row.get("Nome", "") or code),
                phase=int(row.get("Fase", 1)) if int(row.get("Fase", 1)) in (1, 2) else 1,
                selected=bool(row.get("Selecionado", True)),
                weight=float(row.get("Peso", 1) or 0),
                is_cost=bool(row.get("Custo/Risco?", False)),
                order=int(row.get("Ordem", 0) or 0),
                description=str(row.get("Descrição", "") or ""),
                levels=levels,
                neutral_level=neutral_level,
                best_level=best_level,
            )
        )
    st.session_state.analysis.criteria = new_criteria


def apply_scores_dataframe(df: pd.DataFrame) -> None:
    scores = {}
    criterion_codes = [c.code for c in st.session_state.analysis.criteria]
    for _, row in df.iterrows():
        alt_name = str(row.get("Alternativa", "")).strip()
        if not alt_name:
            continue
        scores[alt_name] = {}
        for code in criterion_codes:
            scores[alt_name][code] = float(row.get(code, 0) or 0)
    st.session_state.analysis.scores = scores


def render_sidebar():
    st.sidebar.title("📊 MMASSITI Moderno")
    st.sidebar.caption("Protótipo Python + JSON")

    files = list_analysis_files()
    labels = [p.name for p in files]
    current = Path(st.session_state.get("current_path", "")).name
    selected_index = labels.index(current) if current in labels else 0

    selected = st.sidebar.selectbox("Análise", labels, index=selected_index if labels else None)
    if selected:
        selected_path = DATA_DIR / selected
        if st.sidebar.button("Abrir análise"):
            st.session_state.analysis = load_analysis(selected_path)
            st.session_state.current_path = str(selected_path)
            st.rerun()

    st.sidebar.divider()

    if st.sidebar.button("Criar nova análise"):
        st.session_state.analysis = Analysis(name="Nova análise")
        st.session_state.current_path = str(DATA_DIR / "Nova análise.json")
        rerun_save(st.session_state.current_path)
        st.rerun()

    if st.sidebar.button("Carregar exemplo"):
        st.session_state.analysis = create_sample_analysis()
        st.session_state.current_path = str(DATA_DIR / "sample_analysis.json")
        rerun_save(st.session_state.current_path)
        st.rerun()

    if st.sidebar.button("Guardar agora"):
        rerun_save()

    st.sidebar.divider()
    st.sidebar.download_button(
        "Descarregar JSON",
        data=analysis_to_json(st.session_state.analysis),
        file_name=f"{st.session_state.analysis.name}.json",
        mime="application/json",
    )


def page_overview():
    analysis: Analysis = st.session_state.analysis

    st.header("1. Análise")
    col1, col2 = st.columns([2, 1])

    with col1:
        analysis.name = st.text_input("Nome da análise", analysis.name)
        analysis.description = st.text_area("Descrição", analysis.description, height=100)
        analysis.notes = st.text_area("Notas", analysis.notes, height=100)

    with col2:
        analysis.methodology = st.selectbox(
            "Metodologia",
            ["1fase", "2fases", "1e2fases"],
            index=["1fase", "2fases", "1e2fases"].index(analysis.methodology),
        )
        analysis.created_by = st.text_input("Responsável", analysis.created_by)

        st.metric("Alternativas", len(analysis.alternatives))
        st.metric("Critérios", len(analysis.criteria))

    if st.button("Guardar alterações da análise"):
        rerun_save()


def page_alternatives():
    st.header("2. Alternativas")
    st.caption("Edite diretamente a tabela. Cada alternativa pode ter um custo para análise benefício/custo.")

    df = alternatives_dataframe(st.session_state.analysis)
    edited = st.data_editor(
        df,
        num_rows="dynamic",
        use_container_width=True,
        column_config={
            "Custo": st.column_config.NumberColumn("Custo", min_value=0.0, step=1000.0),
            "Selecionada para 2.ª fase": st.column_config.CheckboxColumn("Selecionada para 2.ª fase"),
        },
    )

    if st.button("Aplicar alternativas"):
        apply_alternatives_dataframe(edited)
        # Garante entradas no dicionário de scores
        for alt in st.session_state.analysis.alternatives:
            st.session_state.analysis.scores.setdefault(alt.name, {})
        rerun_save()
        st.rerun()


def page_criteria():
    st.header("3. Critérios")
    st.caption("Os pesos são normalizados automaticamente no cálculo. Pode usar pesos 0–100, pontos Swing, ou qualquer escala relativa.")

    df = criteria_dataframe(st.session_state.analysis)
    edited = st.data_editor(
        df,
        num_rows="dynamic",
        use_container_width=True,
        column_config={
            "Fase": st.column_config.SelectboxColumn("Fase", options=[1, 2]),
            "Selecionado": st.column_config.CheckboxColumn("Selecionado"),
            "Peso": st.column_config.NumberColumn("Peso", min_value=0.0, step=1.0),
            "Custo/Risco?": st.column_config.CheckboxColumn("Custo/Risco?"),
        },
    )

    if st.button("Aplicar critérios"):
        apply_criteria_dataframe(edited)
        rerun_save()
        st.rerun()

    st.subheader("Pesos normalizados")
    for phase in (1, 2):
        criteria = [c for c in st.session_state.analysis.criteria if c.phase == phase and c.selected]
        weights = normalize_weights(criteria)
        if weights:
            st.markdown(f"**Fase {phase}**")
            st.dataframe(
                pd.DataFrame([
                    {"Código": c.code, "Critério": c.name, "Peso original": c.weight, "Peso normalizado": weights[c.code]}
                    for c in criteria
                ]),
                use_container_width=True,
            )


def page_levels():
    st.header("4. Níveis de atratividade")
    st.caption("Opcional. Os níveis ajudam a documentar escalas como Fraco/Médio/Bom/Excelente.")

    analysis: Analysis = st.session_state.analysis
    if not analysis.criteria:
        st.info("Crie primeiro critérios.")
        return

    code = st.selectbox("Critério", [c.code for c in analysis.criteria])
    criterion = next(c for c in analysis.criteria if c.code == code)

    st.markdown(f"### {criterion.code} — {criterion.name}")

    df = pd.DataFrame([
        {"Nível": l.name, "Valor": l.score, "Descrição": l.description}
        for l in criterion.levels
    ])

    edited = st.data_editor(
        df,
        num_rows="dynamic",
        use_container_width=True,
        column_config={
            "Valor": st.column_config.NumberColumn("Valor", step=1.0),
        },
    )

    col1, col2 = st.columns(2)
    with col1:
        criterion.neutral_level = st.text_input("Nível neutro", criterion.neutral_level or "")
    with col2:
        criterion.best_level = st.text_input("Nível melhor", criterion.best_level or "")

    if st.button("Aplicar níveis"):
        criterion.levels = [
            Level(
                name=str(row.get("Nível", "")).strip(),
                score=float(row.get("Valor", 0) or 0),
                description=str(row.get("Descrição", "") or ""),
            )
            for _, row in edited.iterrows()
            if str(row.get("Nível", "")).strip()
        ]
        rerun_save()
        st.rerun()


def page_scores():
    st.header("5. Avaliação das alternativas")
    st.caption("Introduza valores por alternativa e critério. A escala recomendada é 0–100.")

    if not st.session_state.analysis.alternatives or not st.session_state.analysis.criteria:
        st.info("Crie primeiro alternativas e critérios.")
        return

    df = scores_dataframe(st.session_state.analysis)
    config = {
        c.code: st.column_config.NumberColumn(f"{c.code} — {c.name}", step=1.0)
        for c in st.session_state.analysis.criteria
    }

    edited = st.data_editor(
        df,
        use_container_width=True,
        column_config=config,
        disabled=["Alternativa"],
    )

    if st.button("Aplicar avaliações"):
        apply_scores_dataframe(edited)
        rerun_save()
        st.rerun()


def page_results():
    st.header("6. Resultados")

    results = evaluate_all(st.session_state.analysis)
    if not results:
        st.info("Não existem critérios selecionados para calcular resultados.")
        return

    for phase, df in results.items():
        st.subheader(f"Fase {phase}")
        st.dataframe(df, use_container_width=True)

        if not df.empty:
            chart_df = df[["Alternativa", "Valor Global"]].copy()
            fig = px.bar(chart_df, x="Alternativa", y="Valor Global", title=f"Valor Global — Fase {phase}")
            st.plotly_chart(fig, use_container_width=True)

            bc = df.dropna(subset=["Benefício/Custo"])
            if not bc.empty:
                fig2 = px.bar(bc, x="Alternativa", y="Benefício/Custo", title=f"Benefício/Custo — Fase {phase}")
                st.plotly_chart(fig2, use_container_width=True)

        csv = df.to_csv(index=False).encode("utf-8")
        st.download_button(
            f"Descarregar resultados da fase {phase} em CSV",
            data=csv,
            file_name=f"resultados_fase_{phase}.csv",
            mime="text/csv",
        )


def page_sensitivity():
    st.header("7. Sensibilidade e robustez")

    phase = st.selectbox("Fase", [1, 2])
    criteria = [c for c in st.session_state.analysis.criteria if c.phase == phase and c.selected]
    if not criteria:
        st.info("Não existem critérios selecionados nesta fase.")
        return

    criterion_code = st.selectbox("Critério para análise de sensibilidade", [c.code for c in criteria])
    min_factor, max_factor = st.slider("Intervalo de variação do peso", 0.1, 3.0, (0.5, 2.0), 0.1)
    steps = st.slider("Número de pontos", 3, 15, 7)

    factors = [min_factor + i * (max_factor - min_factor) / (steps - 1) for i in range(steps)]
    sens_df = sensitivity_analysis(st.session_state.analysis, phase, criterion_code, factors)

    st.subheader("Análise de sensibilidade")
    st.dataframe(sens_df, use_container_width=True)

    if not sens_df.empty:
        fig = px.line(
            sens_df,
            x="Multiplicador do Peso",
            y="Valor Global",
            color="Alternativa",
            markers=True,
            title=f"Sensibilidade ao peso de {criterion_code}",
        )
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Análise de robustez")
    delta = st.slider("Variação percentual dos pesos", 0.01, 0.50, 0.10, 0.01)
    rob_df = robustness_analysis(st.session_state.analysis, phase, delta)
    st.dataframe(rob_df, use_container_width=True)


def page_json():
    st.header("8. JSON / Importação e exportação")
    st.caption("Pode editar diretamente o JSON. Útil para integração com outros sistemas ou versionamento em Git.")

    text = st.text_area("JSON da análise", analysis_to_json(st.session_state.analysis), height=500)

    col1, col2 = st.columns(2)
    with col1:
        if st.button("Validar e carregar JSON"):
            try:
                st.session_state.analysis = load_analysis_from_json_text(text)
                rerun_save()
                st.success("JSON carregado com sucesso.")
                st.rerun()
            except Exception as e:
                st.error(f"Erro ao validar JSON: {e}")

    with col2:
        st.download_button(
            "Descarregar JSON atual",
            data=analysis_to_json(st.session_state.analysis),
            file_name=f"{st.session_state.analysis.name}.json",
            mime="application/json",
        )


def main():
    init_state()
    render_sidebar()

    st.title("MMASSITI Moderno")
    st.caption("Metodologia multicritério de apoio à seleção de SI/TI — protótipo em Python")

    tabs = st.tabs([
        "Análise",
        "Alternativas",
        "Critérios",
        "Níveis",
        "Avaliações",
        "Resultados",
        "Sensibilidade",
        "JSON",
    ])

    with tabs[0]:
        page_overview()
    with tabs[1]:
        page_alternatives()
    with tabs[2]:
        page_criteria()
    with tabs[3]:
        page_levels()
    with tabs[4]:
        page_scores()
    with tabs[5]:
        page_results()
    with tabs[6]:
        page_sensitivity()
    with tabs[7]:
        page_json()


if __name__ == "__main__":
    main()
